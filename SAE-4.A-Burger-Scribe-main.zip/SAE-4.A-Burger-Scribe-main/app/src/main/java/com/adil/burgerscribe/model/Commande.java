package com.adil.burgerscribe.model;

import java.util.ArrayList;

public class Commande {
	private int id;

	private static int idNow;
	private int id_User;
	private ArrayList<Burger> commande;
	private String statut;

	public Commande(int id, int id_User, ArrayList<Burger> commande, String statut) {
		this.id = idNow ++;
		this.id_User = id_User;
		this.commande = commande;
		this.statut = statut;
	}

	public int getId() {
		return id;
	}

	public int getId_User() {
		return id_User;
	}

	public ArrayList<Burger> getCommande() {
		return commande;
	}

	public String getStatut() {
		return statut;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setId_User(int id_User) {
		this.id_User = id_User;
	}

	public void setCommande(ArrayList<Burger> commande) {
		this.commande = commande;
	}

	public void setStatut(String statut) {
		this.statut = statut;
	}

	public void ajouterBurger(Burger burger) {
		commande.add(burger);
	}

	public void supprimerBurger(int index) {
		commande.remove(index);
	}

	public double calculerPrixTotal() {
		double prixTotal = 0;
		for (Burger burger : commande) {
			//prixTotal += burger.getPrix();
		}
		return prixTotal;
	}
}
