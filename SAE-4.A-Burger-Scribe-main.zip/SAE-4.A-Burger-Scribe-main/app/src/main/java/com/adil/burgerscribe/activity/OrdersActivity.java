package com.adil.burgerscribe.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.adil.burgerscribe.ApiClient;
import com.adil.burgerscribe.ApiService;
import com.adil.burgerscribe.R;
import com.adil.burgerscribe.model.Panier;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import android.content.Context;
import android.view.LayoutInflater;

public class OrdersActivity extends AppCompatActivity {

    private TextView back, commande_prete_vide, commande_preparation_vide;
    private String userId;
    private LinearLayout inProgressContainer, completedContainer;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_orders);

        SharedPreferences preferences = getSharedPreferences("user_info", MODE_PRIVATE);
        userId = preferences.getString("id", "");

        back = findViewById(R.id.back);
        commande_prete_vide = findViewById(R.id.commande_prete_vide);
        commande_preparation_vide = findViewById(R.id.commande_preparation_vide);
        inProgressContainer = findViewById(R.id.in_progress_container);
        completedContainer = findViewById(R.id.completed_container);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(OrdersActivity.this, MainActivity.class);
                intent.putExtra("selectedItemId", R.id.account);
                startActivity(intent);
                finish();
            }
        });

        fetchOrders();
    }

    private void addOrderCard(LinearLayout container, String orderId, String orderStatus, double orderPrice, int articleCount) {
        LayoutInflater inflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View orderCard = inflater.inflate(R.layout.card_item_order, null);

        TextView orderIdView = orderCard.findViewById(R.id.order_name);
        TextView orderStatusView = orderCard.findViewById(R.id.statut);
        TextView orderDetailsView = orderCard.findViewById(R.id.count_burger);
        TextView orderPriceView = orderCard.findViewById(R.id.order_price);
        ImageView orderStatusImage = orderCard.findViewById(R.id.order_image);

        orderIdView.setText("Commande n°" + orderId.substring(orderId.length() - 5));
        orderStatusView.setText(orderStatus);
        orderPriceView.setText(String.format("%.2f €", orderPrice));
        if (articleCount > 1) {
            orderDetailsView.setText(articleCount + " articles");
        } else {
            orderDetailsView.setText(articleCount + " article");
        }

        if (orderStatus.equals("in progress")) {
            orderStatusImage.setImageResource(R.drawable.in_progress);
        } else if (orderStatus.equals("completed")) {
            //orderStatusImage.setImageResource(R.drawable.completed);
        }
        container.addView(orderCard);
    }

    private void fetchOrders() {
        ApiService apiService = ApiClient.getInstance().getApiService();
        Call<ArrayList<Panier>> call = apiService.getPaniersUser(userId);
        call.enqueue(new Callback<ArrayList<Panier>>() {
            @Override
            public void onResponse(Call<ArrayList<Panier>> call, Response<ArrayList<Panier>> response) {
                if (response.isSuccessful()) {
                    List<Panier> orders = response.body();
                    for (Panier order : orders) {
                        String orderId = order.getId();
                        String orderStatus = order.getStatus();
                        int articleCount = order.getBurgers().size();
                        double orderPrice = order.getPrixTotal();

                        if (orderStatus.equals("in progress")) {
                            addOrderCard(inProgressContainer, orderId, "en cours de préparation", orderPrice, articleCount);
                            commande_preparation_vide.setVisibility(View.GONE);
                        } else if (orderStatus.equals("completed")) {
                            addOrderCard(completedContainer, orderId, "prête", orderPrice, articleCount);
                            commande_prete_vide.setVisibility(View.GONE);
                        }
                    }
                }
            }

            @Override
            public void onFailure(Call<ArrayList<Panier>> call, Throwable t) {
                Toast.makeText(OrdersActivity.this, "Erreur de connexion", Toast.LENGTH_SHORT).show();
            }
        });
    }

}
