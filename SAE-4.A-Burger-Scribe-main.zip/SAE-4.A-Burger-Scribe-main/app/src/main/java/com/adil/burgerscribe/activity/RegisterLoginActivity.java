package com.adil.burgerscribe.activity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.adil.burgerscribe.ApiClient;
import com.adil.burgerscribe.ApiResponse;
import com.adil.burgerscribe.R;
import com.adil.burgerscribe.model.User;
import com.google.android.material.textfield.TextInputEditText;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class RegisterLoginActivity extends AppCompatActivity {
    private static final String TAG = "RegisterLoginActivity";
    private Button mButtonRegister, mButtonLogin;
    private TextInputEditText mEditTextRegisterFirstname, mEditTextRegisterName, mEditTextRegisterEmail, mEditTextRegisterPassword, mEditTextLoginEmail, mEditTextLoginPassword;
    private Button mNav_register, mNav_login;
    private LinearLayout mLayoutRegisterForm, mLayoutLoginForm;

    private boolean isRegisterFormVisible = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_login);

        mButtonRegister = findViewById(R.id.button_register_submit);
        mButtonLogin = findViewById(R.id.button_login_submit);
        mEditTextRegisterName = findViewById(R.id.editText_name);
        mEditTextRegisterFirstname = findViewById(R.id.editText_firstname);
        mEditTextRegisterEmail = findViewById(R.id.editText_email);
        mEditTextRegisterPassword = findViewById(R.id.editText_password);
        mEditTextLoginEmail = findViewById(R.id.editText_email_login);
        mEditTextLoginPassword = findViewById(R.id.editText_password_login);
        mNav_register = findViewById(R.id.nav_register);
        mNav_login = findViewById(R.id.nav_login);
        mLayoutRegisterForm = findViewById(R.id.layout_register_form);
        mLayoutLoginForm = findViewById(R.id.layout_login_form);

        mButtonRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                register();
            }
        });

        mButtonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                login();
            }
        });

        mNav_register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                switchToRegisterForm();
            }
        });

        mNav_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                switchToLoginForm();
            }
        });

    }

    private void register() {
        String name = mEditTextRegisterName.getText().toString().trim();
        String firstname = mEditTextRegisterFirstname.getText().toString().trim();
        String email = mEditTextRegisterEmail.getText().toString().trim();
        String password = mEditTextRegisterPassword.getText().toString().trim();

        if (firstname.isEmpty() || name.isEmpty() || email.isEmpty() || password.isEmpty()) {
            Toast.makeText(RegisterLoginActivity.this, "Veuillez remplir les champs requis", Toast.LENGTH_SHORT).show();
            return;
        }

        User user = new User(firstname, name, email, password);
        Call<ApiResponse> call = ApiClient.getInstance().getApiService().registerUser(user);
        call.enqueue(new Callback<ApiResponse>() {
            @Override
            public void onResponse(Call<ApiResponse> call, Response<ApiResponse> response) {
                if (response.isSuccessful()) {
                    Toast.makeText(RegisterLoginActivity.this, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                } else {
                    String errorMessage;
                    try {
                        JSONObject errorJson = new JSONObject(response.errorBody().string());
                        errorMessage = errorJson.getString("message");
                    } catch (IOException | JSONException e) {
                        errorMessage = "Erreur lors de l'inscription";
                    }
                    Toast.makeText(RegisterLoginActivity.this, errorMessage, Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<ApiResponse> call, Throwable t) {
                Log.e("API_ERROR", "Erreur de connexion", t);
                Toast.makeText(RegisterLoginActivity.this, "Erreur de connexion", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void login() {
        String email = mEditTextLoginEmail.getText().toString().trim();
        String password = mEditTextLoginPassword.getText().toString().trim();

        if (email.isEmpty() || password.isEmpty()) {
            Toast.makeText(RegisterLoginActivity.this, "Veuillez remplir les champs requis", Toast.LENGTH_SHORT).show();
            return;
        }
        User user = new User(null, null, email, password);
        Call<ApiResponse> call = ApiClient.getInstance().getApiService().loginUser(user);
        call.enqueue(new Callback<ApiResponse>() {
            @Override
            public void onResponse(Call<ApiResponse> call, Response<ApiResponse> response) {
                if (response.isSuccessful()) {
                    Toast.makeText(RegisterLoginActivity.this, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    // Enregistrez les informations de l'utilisateur et passez à l'activité principale
                    user.setFirstname(response.body().getFirstname());
                    user.setLastname(response.body().getLastname());
                    user.setId(response.body().getId());
                    SharedPreferences preferences = getSharedPreferences("user_info", MODE_PRIVATE);
                    SharedPreferences.Editor editor = preferences.edit();
                    editor.putString("id", user.getId());
                    editor.putString("name", user.getLastname());
                    editor.putString("firstname", user.getFirstname());
                    editor.putString("email", email);
                    editor.apply();
                    Intent intent = new Intent(RegisterLoginActivity.this, MainActivity.class);
                    intent.putExtra("selectedItemId", R.id.home);
                    startActivity(intent);
                    finish();
                } else {
                    String errorMessage;
                    try {
                        JSONObject errorJson = new JSONObject(response.errorBody().string());
                        errorMessage = errorJson.getString("message");
                    } catch (IOException | JSONException e) {
                        errorMessage = "Erreur lors de la connexion";
                    }
                    Toast.makeText(RegisterLoginActivity.this, errorMessage, Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<ApiResponse> call, Throwable t) {
                Log.e("API_ERROR", "Erreur de connexion", t);
                Toast.makeText(RegisterLoginActivity.this, "Erreur de connexion", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void switchToRegisterForm() {
        mLayoutLoginForm.setVisibility(View.GONE);
        mLayoutRegisterForm.setVisibility(View.VISIBLE);
        isRegisterFormVisible = true;
    }

    private void switchToLoginForm() {
        mLayoutRegisterForm.setVisibility(View.GONE);
        mLayoutLoginForm.setVisibility(View.VISIBLE);
        isRegisterFormVisible = false;
    }

}