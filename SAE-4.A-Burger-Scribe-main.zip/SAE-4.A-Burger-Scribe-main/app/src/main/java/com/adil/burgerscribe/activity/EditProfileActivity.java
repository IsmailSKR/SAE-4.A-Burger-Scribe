package com.adil.burgerscribe.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.adil.burgerscribe.ApiClient;
import com.adil.burgerscribe.ApiResponse;
import com.adil.burgerscribe.R;
import com.adil.burgerscribe.model.User;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.navigation.NavigationView;
import com.google.android.material.textfield.TextInputEditText;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class EditProfileActivity extends AppCompatActivity {

    private TextView back;
    private TextInputEditText prenomTextView, nomTextView, emailTextView;

    private MaterialButton saveButton;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_profile);

        SharedPreferences preferences = getSharedPreferences("user_info", MODE_PRIVATE);
        String nom = preferences.getString("name", "");
        String prenom = preferences.getString("firstname", "");
        String email = preferences.getString("email", "");

        back = findViewById(R.id.back);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(EditProfileActivity.this, MainActivity.class);
                intent.putExtra("selectedItemId", R.id.account);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
                finish();
            }
        });
        prenomTextView = findViewById(R.id.prenom);
        nomTextView = findViewById(R.id.nom);
        emailTextView = findViewById(R.id.email);

        prenomTextView.setTextInputLayoutFocusedRectEnabled(true);
        prenomTextView.setText(prenom);
        nomTextView.setTextInputLayoutFocusedRectEnabled(true);
        nomTextView.setText(nom);
        emailTextView.setTextInputLayoutFocusedRectEnabled(true);
        emailTextView.setText(email);

        saveButton = findViewById(R.id.save);
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String firstname = prenomTextView.getText().toString().trim();
                String lastname = nomTextView.getText().toString().trim();
                String email = emailTextView.getText().toString().trim();

                User user = new User(firstname, lastname, email, null);

                Call<ApiResponse> call = ApiClient.getInstance().getApiService().updateUser(user);
                call.enqueue(new Callback<ApiResponse>() {
                    @Override
                    public void onResponse(Call<ApiResponse> call, Response<ApiResponse> response) {
                        if (response.isSuccessful()) {
                            Toast.makeText(EditProfileActivity.this, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                            SharedPreferences preferences = getSharedPreferences("user_info", MODE_PRIVATE);
                            SharedPreferences.Editor editor = preferences.edit();
                            editor.putString("name", lastname);
                            editor.putString("firstname", firstname);
                            editor.putString("email", email);
                            editor.apply();
                            Intent intent = new Intent(EditProfileActivity.this, MainActivity.class);
                            intent.putExtra("selectedItemId", R.id.account);
                            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(intent);
                            finish();
                        } else {
                            String errorMessage;
                            try {
                                JSONObject errorJson = new JSONObject(response.errorBody().string());
                                errorMessage = errorJson.getString("message");
                            } catch (IOException | JSONException e) {
                                errorMessage = "Erreur lors de la mise à jour du profil";
                            }
                            Log.e("API_ERROR", errorMessage);
                        }
                    }

                    @Override
                    public void onFailure(Call<ApiResponse> call, Throwable t) {
                        Log.e("API_ERROR", "Erreur de connexion", t);
                    }
                });
            }
        });
    }
}
