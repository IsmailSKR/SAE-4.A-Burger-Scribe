package com.adil.burgerscribe.activity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.adil.burgerscribe.ApiClient;
import com.adil.burgerscribe.ApiService;
import com.adil.burgerscribe.R;
import com.adil.burgerscribe.model.Burger;
import com.adil.burgerscribe.model.Ingredient;
import com.adil.burgerscribe.model.Panier;
import com.bumptech.glide.Glide;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Locale;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class BurgerActivity extends AppCompatActivity {

	private ImageView burgerImage;
	private TextView burgerName, burgerPrix, burgerDescription, burgerCategorie, back;
	private LinearLayout ingredient1, ingredient2, ingredient3, ingredient4, ingredient5;

	private TextView ingredient_name_1, ingredient_name_2, ingredient_name_3, ingredient_name_4, ingredient_name_5;

	private Button buttonPanier;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_article);

		SharedPreferences preferences = getSharedPreferences("user_info", MODE_PRIVATE);
		String userId = preferences.getString("id", "");

		Intent intent = getIntent();
		Bundle extras = intent.getExtras();
		String nom = extras.getString("burger_name");
		ArrayList<Ingredient> ingredients = extras.getParcelableArrayList("ingredients");
		Double prix = extras.getDouble("burger_prix");
		String categorie = extras.getString("categorie");
		String description = extras.getString("description");
		String image = extras.getString("burger_image");
		burgerImage = findViewById(R.id.burger_detail_image);
		burgerName = findViewById(R.id.burger_detail_name);
		burgerPrix = findViewById(R.id.burger_detail_prix);
		burgerCategorie = findViewById(R.id.burger_categorie);
		burgerDescription = findViewById(R.id.burger_detail_description);
		buttonPanier = findViewById(R.id.addPanier);
		ingredient1 = findViewById(R.id.ingredient1);
		ingredient2 = findViewById(R.id.ingredient2);
		ingredient3 = findViewById(R.id.ingredient3);
		ingredient4 = findViewById(R.id.ingredient4);
		ingredient5 = findViewById(R.id.ingredient5);
		back = findViewById(R.id.back);

		back.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				Class<?> previousActivityClass = null;
				int previousActivityId = intent.getIntExtra("previousActivityId", -1);
				if (previousActivityId == R.id.account) {
					previousActivityClass = AccountFragment.class;
				} else if (previousActivityId == R.id.home) {
					previousActivityClass = IntroActivity.class;
				}
				if (previousActivityClass != null) {
					Intent previousActivityIntent = new Intent(BurgerActivity.this, previousActivityClass);
					previousActivityIntent.putExtra("selectedItemId", previousActivityId);
					startActivity(previousActivityIntent);
				} else {
					finish();
				}
			}
		});
		buttonPanier.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				SharedPreferences prefs = getSharedPreferences("user_info", MODE_PRIVATE);
				String id = prefs.getString("id", "");
				Burger burgerToAdd = new Burger(nom, categorie, description, prix, ingredients, image, 1, true);


				ApiService apiService = ApiClient.getInstance().getApiService();
				Call<Panier> call = apiService.addBurgerToPanier(id, burgerToAdd);


				call.enqueue(new Callback<Panier>() {
					@Override
					public void onResponse(Call<Panier> call, Response<Panier> response) {
						if (response.isSuccessful()) {
							Panier panier = response.body();
							Toast.makeText(getApplicationContext(), "Burger ajouté au panier", Toast.LENGTH_SHORT).show();
						} else {
							Toast.makeText(getApplicationContext(), "Erreur 2 : " + response.code(), Toast.LENGTH_SHORT).show();
							ResponseBody responseBody = response.errorBody();
							try {
								String json = responseBody.string();
								Log.d("BurgerActivity", "JSON received: " + json);
							} catch (IOException e) {
								Log.e("BurgerActivity", "IOException while reading response body", e);
							}
						}
					}

					@Override
					public void onFailure(Call<Panier> call, Throwable t) {
						// Afficher l'erreur à l'utilisateur
						Toast.makeText(getApplicationContext(), "Erreur 1 : " + t.getMessage(), Toast.LENGTH_SHORT).show();
						Log.e("BurgerActivity", "onFailure: Échec de la récupération du panier", t);
					}
				});

			}
		});


		System.out.println(nom + "\n\n\n\n\n");
		Glide.with(this).load(image).into(burgerImage);
		burgerName.setText(nom);
		burgerDescription.setText(description);
		burgerPrix.setText(String.format("%.2f €", prix));
		burgerCategorie.setText(categorie);
		ingredient_name_1 = ingredient1.findViewById(R.id.ingredient_name);
		ingredient_name_2 = ingredient2.findViewById(R.id.ingredient_name);
		ingredient_name_3 = ingredient3.findViewById(R.id.ingredient_name);
		ingredient_name_4 = ingredient4.findViewById(R.id.ingredient_name);
		ingredient_name_5 = ingredient5.findViewById(R.id.ingredient_name);

		ingredient_name_1.setText("Viande");
		ingredient_name_2.setText("Fromage");
		ingredient_name_3.setText("Salade");
		ingredient_name_4.setText("Tomate");
		ingredient_name_5.setText("Oignon rouge");
		TextView[] textViewsIngredients = {ingredient_name_1, ingredient_name_2, ingredient_name_3, ingredient_name_4, ingredient_name_5};

		setIngredients(ingredients, textViewsIngredients);
	}


	private void setIngredients(ArrayList<Ingredient> ingredients, TextView[] textViewsIngredients) {
		for (int i = 0; i < textViewsIngredients.length; i++) {
			TextView textView = textViewsIngredients[i];
			Ingredient ingredient = findOrCreateIngredient(ingredients, textView);

			textView.setText(ingredient.getName());

			LinearLayout layout = findViewById(getResources().getIdentifier("ingredient" + (i + 1), "id", getPackageName()));
			ImageButton minusButton = layout.findViewById(R.id.button_minus);
			ImageButton plusButton = layout.findViewById(R.id.button_plus);
			TextView textQuantity = layout.findViewById(R.id.quantity);

			textQuantity.setText(String.format(Locale.getDefault(), "%02d", ingredient.getQuantite()));

			setQuantityClickListener(ingredient, ingredients, textQuantity);
			setButtonClickListener(ingredient, ingredients, textQuantity, minusButton, true);
			setButtonClickListener(ingredient, ingredients, textQuantity, plusButton, false);
		}
	}


	private Ingredient findOrCreateIngredient(ArrayList<Ingredient> ingredients, TextView textView) {
		String name = textView.getText().toString();
		for (Ingredient ing : ingredients) {
			if (ing.getName().equals(name)) {
				return ing;
			}
		}
		// Le nouvel ingrédient doit avoir la quantité correcte
		Ingredient ingredient = new Ingredient(name, 0);
		ingredients.add(ingredient);
		return ingredient;
	}

	private void setQuantityClickListener(Ingredient ingredient, ArrayList<Ingredient> ingredients, TextView textQuantity) {
		textQuantity.setOnClickListener(v -> {
			int currentQuantity = ingredient.getQuantite();
			if (currentQuantity > 0) {
				ingredient.setQuantite(currentQuantity - 1);
				textQuantity.setText(String.valueOf(ingredient.getQuantite()));
				if (ingredient.getQuantite() == 0) {
					ingredients.remove(ingredient);
				}
			}
		});
	}

	private void setButtonClickListener(Ingredient ingredient, ArrayList<Ingredient> ingredients, TextView textQuantity, ImageButton button, boolean isMinusButton) {
		button.setOnClickListener(v -> {
			int currentQuantity = ingredient.getQuantite();
			if (isMinusButton && currentQuantity > 0) {
				ingredient.setQuantite(currentQuantity - 1);
			} else if (!isMinusButton) {
				ingredient.setQuantite(currentQuantity + 1);
			}
			textQuantity.setText(String.format(Locale.getDefault(), "%02d", ingredient.getQuantite()));
			if (ingredient.getQuantite() == 0) {
				ingredients.remove(ingredient);
			}
		});
	}





}
