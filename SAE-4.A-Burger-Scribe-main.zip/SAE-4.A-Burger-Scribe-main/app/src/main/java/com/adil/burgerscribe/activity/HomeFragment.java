package com.adil.burgerscribe.activity;

import static android.content.Context.MODE_PRIVATE;

import androidx.fragment.app.Fragment;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.core.content.res.ResourcesCompat;
import androidx.viewpager.widget.ViewPager;

import com.adil.burgerscribe.ApiClient;
import com.adil.burgerscribe.ApiService;
import com.adil.burgerscribe.CarouselAdapter;
import com.adil.burgerscribe.R;
import com.adil.burgerscribe.model.Burger;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.bitmap.CenterCrop;
import com.bumptech.glide.load.resource.bitmap.RoundedCorners;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class HomeFragment extends Fragment {

    private ViewPager burgerCarousel;
    private Handler handler;
    private Runnable runnable;
    private TextView title, burgerTitle, viewall;
    private ArrayList<Burger> burgers;
    private int lastSelectedCardId = R.id.filtre1;
    private View view, card;
    private CardView filtre1, filtre2, filtre3, filtre4;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_home, container, false);

        SharedPreferences preferences = getActivity().getSharedPreferences("user_info", MODE_PRIVATE);
        String name = preferences.getString("firstname", "");

        int selectedItemId = getActivity().getIntent().getIntExtra("selectedItemId", R.id.home);

        burgerCarousel = view.findViewById(R.id.burgerCarousel);
        viewall = view.findViewById(R.id.more);
        burgerTitle= view.findViewById(R.id.burgerTitle);
        title = view.findViewById(R.id.title);
        filtre1 = view.findViewById(R.id.filtre1);
        filtre2 = view.findViewById(R.id.filtre2);
        filtre3 = view.findViewById(R.id.filtre3);
        filtre4 = view.findViewById(R.id.filtre4);
        viewall = view.findViewById(R.id.more);
        card = inflater.inflate(R.layout.card_item, null);


        title.setText("Bonjour, " + name);


        Drawable gradientBackground = ResourcesCompat.getDrawable(getResources(), R.drawable.card_background_gradient, null);
        filtre1.setBackground(gradientBackground);
        TextView text = filtre1.findViewById(R.id.filtre_name);
        text.setTextColor(Color.parseColor("#FFFFFF"));


        setupOnClickListeners();
        setupBurgerCarousel();
        setupBurgers();
        setupFiltreName();

        handler = new Handler();
        runnable = new Runnable() {
            @Override
            public void run() {
                int currentPosition = burgerCarousel.getCurrentItem();
                int nextPosition = (currentPosition + 1) % 3;
                burgerCarousel.setCurrentItem(nextPosition, true);
                handler.postDelayed(this, 5000);
            }
        };
        return view;
    }

    private void changeSelectedCard(CardView newSelectedCard) {
        CardView lastSelectedCard = view.findViewById(lastSelectedCardId);
        Drawable whiteBackground = ResourcesCompat.getDrawable(getResources(), R.drawable.card_background_white, null);
        lastSelectedCard.setBackground(whiteBackground);
        TextView text = lastSelectedCard.findViewById(R.id.filtre_name);
        text.setTextColor(Color.parseColor("#404040"));

        Drawable gradientBackground = ResourcesCompat.getDrawable(getResources(), R.drawable.card_background_gradient, null);
        newSelectedCard.setBackground(gradientBackground);
        text = newSelectedCard.findViewById(R.id.filtre_name);
        text.setTextColor(Color.parseColor("#FFFFFF"));

        lastSelectedCardId = newSelectedCard.getId();

        String selectedCategory = ((TextView) newSelectedCard.findViewById(R.id.filtre_name)).getText().toString();
        burgerTitle.setText("Burgers " + selectedCategory);
        ArrayList<Burger> filteredBurgers;

        filteredBurgers = filterBurgersByCategory(burgers, selectedCategory);
        LinearLayout container = view.findViewById(R.id.burger_container);
        container.removeAllViews();
        displayBurgers(filteredBurgers);
    }


    private void setupBurgerCarousel() {
        List<Integer> burgerImages = Arrays.asList(
                R.drawable.slide1,
                R.drawable.slide2,
                R.drawable.slide3
        );

        List<ImageView> burgerImageViews = new ArrayList<>();
        for (int i = 0; i < burgerImages.size(); i++) {
            ImageView imageView = new ImageView(getActivity());
            Glide.with(this)
                    .load(burgerImages.get(i))
                    .transform(new CenterCrop(), new RoundedCorners(70))
                    .into(imageView);
            burgerImageViews.add(imageView);
        }

        CarouselAdapter carouselAdapter = new CarouselAdapter(getActivity(), burgerImageViews);
        burgerCarousel.setAdapter(carouselAdapter);
    }

    private void setupFiltreName() {
        TextView filtreName1 = filtre1.findViewById(R.id.filtre_name);
        ImageView filtreImage1 = filtre1.findViewById(R.id.filtre_image);
        filtreName1.setText("Populaire");
        filtreImage1.setImageResource(R.drawable.populaire);

        TextView filtreName2 = filtre2.findViewById(R.id.filtre_name);
        ImageView filtreImage2 = filtre2.findViewById(R.id.filtre_image);
        filtreName2.setText("Halal");
        filtreImage2.setImageResource(R.drawable.halal);

        TextView filtreName3 = filtre3.findViewById(R.id.filtre_name);
        ImageView filtreImage3 = filtre3.findViewById(R.id.filtre_image);
        filtreName3.setText("Végétarien");
        filtreImage3.setImageResource(R.drawable.vegetarien);

        TextView filtreName4 = filtre4.findViewById(R.id.filtre_name);
        ImageView filtreImage4 = filtre4.findViewById(R.id.filtre_image);
        filtreName4.setText("Épicé");
        filtreImage4.setImageResource(R.drawable.epice);
    }

    private ArrayList<Burger> filterBurgersByCategory(ArrayList<Burger> allBurgers, String category) {
        ArrayList<Burger> filteredBurgers = new ArrayList<>();

        for (Burger burger : allBurgers) {
            if (burger.getCategorie().equalsIgnoreCase(category)) {
                filteredBurgers.add(burger);
            }
        }

        return filteredBurgers;
    }

    private void setupBurgers() {
        ApiService apiService = ApiClient.getInstance().getApiService();

        Call<ArrayList<Burger>> call = apiService.getBurgers();

        call.enqueue(new Callback<ArrayList<Burger>>() {
            @Override
            public void onResponse(Call<ArrayList<Burger>> call, Response<ArrayList<Burger>> response) {
                if (response.isSuccessful()) {
                    Log.d("API_DEBUG", "Burger object: " + response.body());
                    burgers = response.body();
                    if (!burgers.isEmpty()) {
                        displayBurgers(burgers);
                        changeSelectedCard(filtre1);
                    } else {
                        // Gérer le cas où la liste des burgers est vide
                        Toast.makeText(getActivity(), "La liste des burgers est vide", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    // Gérer l'erreur en cas de réponse non réussie de l'API
                    Toast.makeText(getActivity(), "Erreur lors de la récupération des données des burgers", Toast.LENGTH_SHORT).show();
                }

            }

            @Override
            public void onFailure(Call<ArrayList<Burger>> call, Throwable t) {
                // Gérer l'erreur en cas de problème de connexion ou d'erreur lors de l'envoi de la requête
                Log.e("API_ERROR", "Erreur lors de la récupération des données des burgers", t);
                Toast.makeText(getActivity(), "Erreur lors de la récupération des données des burgers", Toast.LENGTH_SHORT).show();
            }
        });

    }

    private void displayBurgers(ArrayList<Burger> burgers) {
        LinearLayout container = view.findViewById(R.id.burger_container);
        container.removeAllViews();

        for (int i = 0; i < burgers.size() && !burgers.get(i).isCustom(); i += 2) {
            LinearLayout row = new LinearLayout(getActivity());
            row.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_HORIZONTAL);
            row.setPadding(0, 20, 0, 0);

            View card1 = createCardView(burgers.get(i));
            LinearLayout.LayoutParams layoutParams1 = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1);
            layoutParams1.setMargins(5, 0, 5, 0);
            card1.setLayoutParams(layoutParams1);
            row.addView(card1);
            final int index = i;
            card1.setOnClickListener(new CardView.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(getActivity(), BurgerActivity.class);
                    Bundle extras = new Bundle();
                    extras.putDouble("burger_prix", burgers.get(index).getPrix());
                    extras.putString("description", burgers.get(index).getDescription());
                    extras.putString("burger_image", burgers.get(index).getImageUrl());
                    extras.putString("categorie", burgers.get(index).getCategorie());
                    extras.putParcelableArrayList("ingredients", burgers.get(index).getIngredients());
                    extras.putString("burger_name", burgers.get(index).getName());
                    intent.putExtras(extras);
                    startActivity(intent);
                }
            });

            if (i + 1 < burgers.size() && !burgers.get(i + 1).isCustom()) {
                final int index2 = i + 1;
                View card2 = createCardView(burgers.get(i + 1));
                LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1);
                layoutParams2.setMargins(5, 0, 5, 0);
                card2.setLayoutParams(layoutParams2);
                row.addView(card2);
                card2.setOnClickListener(new CardView.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent(getActivity(), BurgerActivity.class);
                        Bundle extras = new Bundle();
                        extras.putDouble("burger_prix", burgers.get(index2).getPrix());
                        extras.putString("description", burgers.get(index2).getDescription());
                        extras.putString("burger_image", burgers.get(index2).getImageUrl());
                        extras.putString("categorie", burgers.get(index2).getCategorie());
                        extras.putParcelableArrayList("ingredients", burgers.get(index2).getIngredients());
                        extras.putString("burger_name", burgers.get(index2).getName());
                        intent.putExtras(extras);
                        startActivity(intent);
                    }
                });
            } else {
                View emptySpace = new View(getActivity());
                LinearLayout.LayoutParams emptySpaceLayoutParams = new LinearLayout.LayoutParams(0, 0, 1);
                emptySpace.setLayoutParams(emptySpaceLayoutParams);
                row.addView(emptySpace);
            }
            container.addView(row);
        }
    }



    private View createCardView(Burger burger) {
        View card = LayoutInflater.from(getActivity()).inflate(R.layout.card_item, null);
        ImageView burgerImage = card.findViewById(R.id.burger_image);
        TextView categoryText = card.findViewById(R.id.category_text);
        TextView burgerName = card.findViewById(R.id.burger_name);
        TextView burgerPrice = card.findViewById(R.id.burger_price);

        Glide.with(this)
                .load(burger.getImageUrl())
                .into(burgerImage);

        categoryText.setText(burger.getCategorie());
        burgerName.setText(burger.getName());
        burgerPrice.setText(String.format("%.2f €", burger.getPrix()));

        return card;
    }




    private void setupOnClickListeners() {
        filtre1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                changeSelectedCard(filtre1);
            }
        });
        filtre2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                changeSelectedCard(filtre2);
            }
        });
        filtre3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                changeSelectedCard(filtre3);
            }
        });
        filtre4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                changeSelectedCard(filtre4);
            }
        });

        viewall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                displayBurgers(burgers);
                burgerTitle.setText("Nos Burgers");
            }
        });
    }

    @Override
    public void onResume() {
        super.onResume();
        handler.postDelayed(runnable, 5000);
    }

    @Override
    public void onPause() {
        super.onPause();
        handler.removeCallbacks(runnable);
    }

}
