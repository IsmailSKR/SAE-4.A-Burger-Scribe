package com.adil.burgerscribe.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.adil.burgerscribe.ApiClient;
import com.adil.burgerscribe.ApiResponse;
import com.adil.burgerscribe.R;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.HashMap;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ChangePasswordActivity extends AppCompatActivity {

    private TextView back;

    private MaterialButton saveButton;

    private TextInputEditText newPassword, oldPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_password);

        SharedPreferences preferences = getSharedPreferences("user_info", MODE_PRIVATE);
        String email = preferences.getString("email", "");

        back = findViewById(R.id.back);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ChangePasswordActivity.this, MainActivity.class);
                intent.putExtra("selectedItemId", R.id.account);
                startActivity(intent);
                finish();
            }
        });

        newPassword = findViewById(R.id.newpassword);
        oldPassword = findViewById(R.id.oldpassword);

        saveButton = findViewById(R.id.save);
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String newPasswordText = newPassword.getText().toString().trim();
                String oldPasswordText = oldPassword.getText().toString().trim();

                if (newPasswordText.isEmpty() || oldPasswordText.isEmpty()) {
                    Toast.makeText(ChangePasswordActivity.this, "Veuillez remplir les champs requis", Toast.LENGTH_SHORT).show();
                } else {
                    HashMap<String, String> passwords = new HashMap<>();
                    passwords.put("newPassword", newPasswordText);
                    passwords.put("oldPassword", oldPasswordText);
                    passwords.put("email", email);

                    Call<ApiResponse> call = ApiClient.getInstance().getApiService().changePassword(passwords);
                    call.enqueue(new Callback<ApiResponse>() {
                        @Override
                        public void onResponse(Call<ApiResponse> call, Response<ApiResponse> response) {
                            if (response.isSuccessful()) {
                                Toast.makeText(ChangePasswordActivity.this, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                                Intent intent = new Intent(ChangePasswordActivity.this, MainActivity.class);
                                intent.putExtra("selectedItemId", R.id.account);
                                startActivity(intent);
                                finish();
                            } else {
                                String errorMessage;
                                try {
                                    JSONObject errorJson = new JSONObject(response.errorBody().string());
                                    errorMessage = errorJson.getString("message");
                                } catch (IOException | JSONException e) {
                                    errorMessage = "Erreur lors de la mise à jour du mot de passe";
                                }
                                Log.e("API_ERROR", errorMessage);
                                Toast.makeText(ChangePasswordActivity.this, errorMessage, Toast.LENGTH_SHORT).show();
                            }
                        }

                        @Override
                        public void onFailure(Call<ApiResponse> call, Throwable t) {
                            Log.e("API_ERROR", "Erreur de connexion", t);
                            Toast.makeText(ChangePasswordActivity.this, "Erreur de connexion", Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            }
        });


    }
}
