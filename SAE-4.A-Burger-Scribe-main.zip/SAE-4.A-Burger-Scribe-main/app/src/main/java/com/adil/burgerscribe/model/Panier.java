package com.adil.burgerscribe.model;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

public class Panier {
    @SerializedName("_id")
    private String id;
    private User user;
    private ArrayList<Burger> burgers;
    private String status;

    private double prixtotal;


    public Panier(String id, User user, ArrayList<Burger> burgers, String status, double prixtotal) {
        this.id = id;
        this.user = user;
        this.burgers = burgers;
        this.status = status;
        this.prixtotal = prixtotal;
    }

    public String getId() {
        return id;
    }

    public User getUser() {
        return user;
    }

    public ArrayList<Burger> getBurgers() {
        return burgers;
    }

    public String getStatus() {
        return status;
    }

    public double getPrixTotal() {
        return prixtotal;
    }

    public void setPrixTotal(double prixtotal) {
        this.prixtotal = prixtotal;
    }
}
