package com.adil.burgerscribe.model;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class Burger {
    @SerializedName("_id")
    private String id;

    @SerializedName("nom")
    private String name;

    @SerializedName("categorie")
    private String categorie;

    @SerializedName("description")
    private String description;

    @SerializedName("ingredients")
    private ArrayList<Ingredient> ingredients;

    @SerializedName("image")
    private String image;

    @SerializedName("prix")
    private Double prix;

    @SerializedName("quantite")
    private int quantity;

    @SerializedName("isCustom")
    private boolean isCustom;

    public Burger(String name, String categorie, String description, Double prix, ArrayList<Ingredient> ingredients, String image, int quantity, boolean isCustom) {
        this.name = name;
        this.categorie = categorie;
        this.description = description;
        this.ingredients = ingredients;
        this.image = image;
        this.prix = prix;
        this.quantity = quantity;
        this.isCustom = isCustom;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public ArrayList<Ingredient> getIngredients() {
        return ingredients;
    }

    public void setIngredients(ArrayList<Ingredient> ingredients) {
        this.ingredients = ingredients;
    }

    public String getImageUrl() {
        return image;
    }

    public void setImageUrl(String imageUrl) {
        this.image = imageUrl;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public boolean isCustom() {
        return isCustom;
    }

    public void setCustom(boolean custom) {
        isCustom = custom;
    }

    public String getCategorie() {
        return categorie;
    }

    public void setCategorie(String categorie) {
        this.categorie = categorie;
    }

    public Double getPrix() {
        return prix;
    }

    public void setPrix(Double prix) {
        this.prix = prix;
    }
}
