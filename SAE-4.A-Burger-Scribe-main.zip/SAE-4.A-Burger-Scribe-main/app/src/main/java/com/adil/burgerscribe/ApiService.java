package com.adil.burgerscribe;

import com.adil.burgerscribe.model.Burger;
import com.adil.burgerscribe.model.Panier;
import com.adil.burgerscribe.model.User;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.DELETE;
import retrofit2.http.GET;
import retrofit2.http.Multipart;
import retrofit2.http.PATCH;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Part;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface ApiService {
    @POST("/register")
    Call<ApiResponse> registerUser(@Body User user);

    @POST("/login")
    Call<ApiResponse> loginUser(@Body User user);

    @GET("/burgers")
    Call<ArrayList<Burger>> getBurgers();

    @GET("/burgers/{id}")
    Call<Burger> getBurgerById(@Path("id") String id);

    @POST("/updateUser")
    Call<ApiResponse> updateUser(@Body User user);

    @POST("/changePassword")
    Call<ApiResponse> changePassword(@Body HashMap<String, String> passwords);

    @GET("/paniers")
    Call<ArrayList<Panier>> getPaniers();

    @GET("/paniers/{userId}")
    Call<Panier> getPanier(@Path("userId") String userId);

    @GET("/orders/{userId}")
    Call<ArrayList<Panier>> getPaniersUser(@Path("userId") String userId);

    @POST("/paniers/{userId}/addBurger")
    Call<Panier> addBurgerToPanier(@Path("userId") String userId, @Body Burger burger);

    @PATCH("/paniers/{panierId}/burgers/{burgerId}/quantity")
    Call<Void> updateBurgerQuantity(@Path("burgerId") String burgerId, @Query("quantity") int quantity);

    @DELETE("/paniers/{panierId}/burgers/{burgerId}")
    Call<Void> removeBurgerFromPanier(@Path("panierId") String panierId, @Path("burgerId") String burgerId);

    @POST("/createPanier")
    Call<ApiResponse> createPanier(@Body Panier panier);

    @PUT("/paniers/{panierId}/status")
    Call<Void> updatePanierStatus(@Path("panierId") String panierId, @Body Map<String, String> status);

    @POST("/updatePanier/{id}")
    Call<Void> updatePanier(@Path("id") String id, @Query("userId") String userId, @Body ArrayList<Burger> burgers, @Query("status") String status);

    @POST("/deletePanier/{id}")
    Call<ApiResponse> deletePanier(@Path("id") String id);
}
