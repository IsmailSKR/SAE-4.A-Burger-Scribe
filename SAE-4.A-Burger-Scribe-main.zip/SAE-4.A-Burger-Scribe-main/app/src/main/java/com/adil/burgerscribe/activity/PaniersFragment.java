package com.adil.burgerscribe.activity;

import static android.content.Context.MODE_PRIVATE;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.fragment.app.Fragment;

import com.adil.burgerscribe.ApiClient;
import com.adil.burgerscribe.ApiResponse;
import com.adil.burgerscribe.ApiService;
import com.adil.burgerscribe.R;
import com.adil.burgerscribe.model.Burger;
import com.adil.burgerscribe.model.Panier;
import com.adil.burgerscribe.model.User;
import com.bumptech.glide.Glide;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.button.MaterialButton;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class PaniersFragment extends Fragment {

    private TextView numberItemsTextView, subtotalTextView, taxTextView, totalTextView;
    private LinearLayout paniersLinearLayout, layoutprice;
    private MaterialButton commanderButton;
    private String userId;

    public static final  String CHANNEL_1_ID = "channel1";

    private NotificationManagerCompat notificationManagerCompat;

    private NotificationManager manager;
    private HashMap<Panier, ImageButton> panierMinusButtons = new HashMap<>();
    private HashMap<Panier, ImageButton> panierPlusButtons = new HashMap<>();

    private HashMap<CardView, Burger> cardViewBurgerMap = new HashMap<>();
    private View view;


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_panier, container, false);
        createNotificationChannels();

        SharedPreferences preferences = getActivity().getSharedPreferences("user_info", MODE_PRIVATE);
        userId = preferences.getString("id", "");

        int selectedItemId = getActivity().getIntent().getIntExtra("selectedItemId", R.id.home);

        numberItemsTextView = view.findViewById(R.id.numberItems);
        paniersLinearLayout = view.findViewById(R.id.paniers);
        commanderButton = view.findViewById(R.id.commander);
        subtotalTextView = view.findViewById(R.id.subtotal_price);
        taxTextView = view.findViewById(R.id.tax_price);
        totalTextView = view.findViewById(R.id.total_price);

        layoutprice = view.findViewById(R.id.layoutprice);
        commanderButton.setVisibility(View.GONE);

        if (userId != null && !userId.isEmpty()) {
            setupBurgers();
        } else {
            Toast.makeText(getActivity(), "Impossible de récupérer le panier : identifiant d'utilisateur manquant", Toast.LENGTH_SHORT).show();
        }
        return view;
    }

    private void updateNumberItems(int count) {
        if (count == 0) {
            numberItemsTextView.setText("Votre panier est vide");
            commanderButton.setVisibility(View.GONE);
            layoutprice.setVisibility(View.GONE);

        } else {
            numberItemsTextView.setText(count + " articles disponibles");
            commanderButton.setVisibility(View.VISIBLE);
            layoutprice.setVisibility(View.VISIBLE);
        }
    }

    private void setupBurgers() {
        ApiService apiService = ApiClient.getInstance().getApiService();
        Call<Panier> call = apiService.getPanier(userId);
        call.enqueue(new Callback<Panier>() {
            @Override
            public void onResponse(Call<Panier> call, Response<Panier> response) {
                if (response.isSuccessful()) {
                    Panier panier = response.body();
                    for (Burger burger : panier.getBurgers()) {
                        LayoutInflater inflater = LayoutInflater.from(getActivity());
                        CardView cardView = (CardView) inflater.inflate(R.layout.card_item_panier, paniersLinearLayout, false);
                        TextView nameTextView = cardView.findViewById(R.id.burger_name);
                        TextView categoryTextView = cardView.findViewById(R.id.category_text);
                        TextView priceTextView = cardView.findViewById(R.id.burger_price);
                        ImageView imageView = cardView.findViewById(R.id.burger_image);
                        ImageButton minusButton = cardView.findViewById(R.id.button_minus);
                        ImageButton plusButton = cardView.findViewById(R.id.button_plus);
                        ImageButton removeButton = cardView.findViewById(R.id.removeButton);
                        TextView quantityTextView = cardView.findViewById(R.id.quantity);



                        nameTextView.setText(burger.getName());
                        categoryTextView.setText(burger.getCategorie());
                        priceTextView.setText(burger.getPrix() + " €");
                        quantityTextView.setText(String.format("%02d", burger.getQuantity()));
                        Glide.with(PaniersFragment.this)
                                .load(burger.getImageUrl())
                                .into(imageView);

                        paniersLinearLayout.addView(cardView);

                        cardView.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                Intent intent = new Intent(getActivity(), BurgerActivity.class);
                                Bundle extras = new Bundle();
                                extras.putDouble("burger_prix", burger.getPrix());
                                extras.putString("description", burger.getDescription());
                                extras.putString("burger_image", burger.getImageUrl());
                                extras.putString("categorie", burger.getCategorie());
                                extras.putParcelableArrayList("ingredients", burger.getIngredients());
                                extras.putString("burger_name", burger.getName());
                                intent.putExtras(extras);
                                startActivity(intent);
                            }
                        });

                        commanderButton.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                sendOnChannel1(panier);
                                Panier newpanier = getPrixPanier(panier);
                                updatePanierStatus(newpanier, "in progress");
                                paniersLinearLayout.removeAllViews();
                                setupBurgers();
                                startActivity(new Intent(getActivity(), OrdersActivity.class).putExtra("selectedItemId", R.id.account));
                            }
                        });

                        updateQuantity(minusButton, plusButton, quantityTextView, burger, panier);

                        removeButton.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                removeBurgerFromPanier(panier, burger, cardView);
                            }
                        });
                        panierMinusButtons.put(panier, minusButton);
                        panierPlusButtons.put(panier, plusButton);
                        cardViewBurgerMap.put(cardView, burger);
                    }
                    updateNumberItems(panier.getBurgers().size());
                    updateAmounts(panier, cardViewBurgerMap);
                } else {
                    Toast.makeText(getActivity(), "Erreur lors de la récupération du panier", Toast.LENGTH_SHORT).show();
                    Log.e("PaniersActivity", "onResponse: Échec de la récupération du panier. Code d'état: " + response.code() + ", Message d'erreur: " + response.message());
                }
            }

            @Override
            public void onFailure(Call<Panier> call, Throwable t) {
                Toast.makeText(getActivity(), "Erreur lors de la récupération du panier", Toast.LENGTH_SHORT).show();
                Log.e("PaniersActivity", "onFailure: Échec de la récupération du panier", t);
            }
        });

    }

    private void updateQuantity(ImageButton minusButton, ImageButton plusButton, TextView quantityTextView, Burger burger, Panier panier) {
        minusButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int quantity = Integer.parseInt(quantityTextView.getText().toString());

                if (quantity > 1) {
                    quantity--;
                }

                quantityTextView.setText(String.format(Locale.getDefault(), "%02d", quantity));
                updatePanier(burger, quantity, panier);
            }
        });

        plusButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int quantity = Integer.parseInt(quantityTextView.getText().toString());
                quantity++;

                quantityTextView.setText(String.format(Locale.getDefault(), "%02d", quantity));
                updatePanier(burger, quantity, panier);
            }
        });
    }



    private void updatePanier(Burger burger, int quantity, Panier panier) {
        ApiService apiService = ApiClient.getInstance().getApiService();
        Call<Void> call = apiService.updateBurgerQuantity(burger.getId(), quantity);
        call.enqueue(new Callback<Void>() {
            @Override
            public void onResponse(Call<Void> call, Response<Void> response) {
                if (!response.isSuccessful()) {
                    Toast.makeText(getActivity(), "Erreur lors de la mise à jour de la quantité du burger", Toast.LENGTH_SHORT).show();
                } else {
                    for (Burger burgerInPanier : panier.getBurgers()) {
                        if (burgerInPanier.getId().equals(burger.getId())) {
                            burgerInPanier.setQuantity(quantity);
                            break;
                        }
                    }
                    updateAmounts(panier, cardViewBurgerMap);
                }
            }

            @Override
            public void onFailure(Call<Void> call, Throwable t) {
                Toast.makeText(getActivity(), "Erreur lors de la mise à jour de la quantité du burger", Toast.LENGTH_SHORT).show();
            }
        });
    }

    public void removeBurgerFromPanier(Panier panier, Burger burger, CardView cardView) {
        panier.getBurgers().remove(burger);

        ApiService apiService = ApiClient.getInstance().getApiService();
        Call<Void> call = apiService.removeBurgerFromPanier(panier.getId(), burger.getId());
        call.enqueue(new Callback<Void>() {
            @Override
            public void onResponse(Call<Void> call, Response<Void> response) {
                if (response.isSuccessful()) {
                    Toast.makeText(getActivity(), "L'article a été supprimé du panier", Toast.LENGTH_SHORT).show();
                    paniersLinearLayout.removeView(cardView);
                    updateNumberItems(panier.getBurgers().size());
                    updateAmounts(panier, cardViewBurgerMap);
                } else {
                    Toast.makeText(getActivity(), "Erreur lors de la suppression de l'article", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<Void> call, Throwable t) {
                Toast.makeText(getActivity(), "Erreur lors de la suppression de l'article", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void updateAmounts(Panier panier, HashMap<CardView, Burger> cardViewBurgerMap) {
        double subtotal = 0;
        double taxRate = 0.20;

        for (Burger burger : panier.getBurgers()) {
            subtotal += burger.getPrix() * burger.getQuantity();
        }

        double tax = subtotal * taxRate;
        double total = subtotal + tax;
        panier.setPrixTotal(total);

        for (CardView cardView : cardViewBurgerMap.keySet()) {
            Burger burger = cardViewBurgerMap.get(cardView);
            TextView priceTextView = cardView.findViewById(R.id.burger_price);
            priceTextView.setText(String.format("%.2f €", burger.getPrix() * burger.getQuantity()));
        }

        subtotalTextView.setText(String.format("%.2f €", subtotal));
        taxTextView.setText(String.format("%.2f €", tax));
        totalTextView.setText(String.format("%.2f €", total));
    }

    private Panier getPrixPanier(Panier panier) {
        double subtotal = 0;
        double taxRate = 0.20;

        for (Burger burger : panier.getBurgers()) {
            subtotal += burger.getPrix() * burger.getQuantity();
        }
        double tax = subtotal * taxRate;
        double total = subtotal + tax;
        panier.setPrixTotal(total);
        return panier;
    }

    private void createNotificationChannels()  {
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel1 = new NotificationChannel(
                    CHANNEL_1_ID,
                    "Channel 1",
                    NotificationManager.IMPORTANCE_HIGH
            );
            channel1.setDescription("This is channel 1");


            manager = getActivity().getSystemService(NotificationManager.class);
            manager.createNotificationChannel(channel1);
        }
    }

    private void sendOnChannel1(Panier panier) {
        String title = "Burgerscribe";
        String message = "Commande validée. Vous avez effectué un paiement de " + String.format("%.2f €", panier.getPrixTotal()) + ".";

        NotificationCompat.BigTextStyle bigTextStyle = new NotificationCompat.BigTextStyle();
        bigTextStyle.setBigContentTitle(title);
        bigTextStyle.bigText(message);

        Notification notification = new NotificationCompat.Builder(getActivity(), PaniersFragment.CHANNEL_1_ID)
                .setSmallIcon(R.drawable.burgerscribe_logo)
                .setLargeIcon(BitmapFactory.decodeResource(getResources(), R.drawable.burgerscribe_logo))
                .setContentTitle(title)
                .setContentText(message)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                .setStyle(bigTextStyle)
                .setAutoCancel(true)
                .build();

        int notificationId = 1;
        this.manager.notify(notificationId, notification);
    }



    private void updatePanierStatus(Panier panier, String status) {
        ApiService apiService = ApiClient.getInstance().getApiService();
        Map<String, String> statusMap = new HashMap<>();
        statusMap.put("status", status);
        statusMap.put("prixtotal", String.valueOf(panier.getPrixTotal()));
        Call<Void> call = apiService.updatePanierStatus(panier.getId(), statusMap);
        call.enqueue(new Callback<Void>() {
            @Override
            public void onResponse(Call<Void> call, Response<Void> response) {
                if (!response.isSuccessful()) {
                    Toast.makeText(getActivity(), "Erreur lors de la mise à jour du statut du panier", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(getActivity(), "Le statut du panier a été mis à jour", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<Void> call, Throwable t) {
                Toast.makeText(getActivity(), "Erreur lors de la mise à jour du statut du panier", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
