package com.adil.burgerscribe.model;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;

import com.google.gson.annotations.SerializedName;

public class Ingredient implements Parcelable {

    @SerializedName("_id")
    private String id;

    @SerializedName("nom")
    private String name;

    @SerializedName("quantite")
    private int quantite;

    public Ingredient(String name) {
        this.name = name;
    }

    public Ingredient(String name, int quantite) {
        this.name = name;
        this.quantite = quantite;
    }


    protected Ingredient(Parcel in) {
        id = in.readString();
        name = in.readString();
        quantite = in.readInt();
    }
    public static final Creator<Ingredient> CREATOR = new Creator<Ingredient>() {
        @Override
        public Ingredient createFromParcel(Parcel in) {
            return new Ingredient(in);
        }

        @Override
        public Ingredient[] newArray(int size) {
            return new Ingredient[size];
        }
    };

    public int getQuantite() {
        return quantite;
    }

    public void setQuantite(int quantite) {
        this.quantite = quantite;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(id);
        dest.writeString(name);
        dest.writeInt(quantite);
    }

    @Override
    public String toString() {
        return name;
    }

}

