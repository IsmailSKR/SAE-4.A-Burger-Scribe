const express = require("express");
const app = express();
const bodyParser = require("body-parser");
const mongoose = require("mongoose");

const authMiddleware = require("./middlewares/authMiddleware");
const authController = require("./controllers/authController");
const burgerController = require("./controllers/burgerController");
const panierController = require("./controllers/panierController");

const User = require("./models/user");
const Ingredient = require("./models/ingredient");
const Burger = require("./models/burger");
const { $where } = require("./models/user");

// Connexion à la base de données

mongoose.set("strictQuery", false);

mongoose
  .connect("mongodb://0.0.0.0:27017/burgerscribe", {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then(() => console.log("Connexion à la base de données réussie"))
  .catch((err) =>
    console.error("Erreur de connexion à la base de données", err)
  );

// Variable pour indiquer si les données ont déjà été insérées
let isDataInserted = false;

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.get("/", (req, res) => {
  res.send("API burgerscribe 1.0");
});

app.listen(3000, () => {
  console.log("Server listening on port 3000");
});

// Routes pour l'authentification des utilisateurs
app.post("/register", authController.register);
app.post("/login", authController.login);
app.post("/updateUser", authController.updateUser);
app.post("/changePassword", authController.changePassword);

// Routes pour la gestion des burgers
app.get("/burgers", burgerController.getBurgers);
app.post("/burgers", burgerController.createBurger);
app.put("/burgers/:id", burgerController.updateBurger);
app.delete("/burgers/:id", burgerController.deleteBurger);

// Routes pour la gestion des paniers
app.get("/paniers", panierController.getPaniers);
app.get("/paniers/:id", panierController.getPanier);
app.get("/orders/:id", panierController.getPaniersUser);
app.post("/paniers/:id/addBurger", panierController.addBurgerToPanier);
app.put("/paniers/:id/status", panierController.updatePanierStatus);
app.patch(
  "/paniers/:panierId/burgers/:burgerId/quantity",
  panierController.updateBurgerQuantity
);
app.delete(
  "/paniers/:panierId/burgers/:burgerId",
  panierController.removeBurgerFromPanier
);
//app.put("/paniers/:id", panierController.updatePanier);
//app.delete("/paniers/:id", panierController.deletePanier);

// Création d'un utilisateur
const userEmail = "adil.chet@gmail.com";

User.findOne({ email: userEmail }, (err, user) => {
  if (err) {
    console.error("Erreur lors de la recherche d'utilisateur", err);
  } else if (user) {
    console.log("Un utilisateur avec cet email existe déjà");
  } else {
    const newUser = new User({
      firstname: "Adil",
      lastname: "Chetouani",
      email: userEmail,
      password: "test1234",
    });

    newUser.save((err) => {
      if (err) {
        console.error("Erreur lors de l'enregistrement de l'utilisateur", err);
      } else {
        console.log("Utilisateur enregistré avec succès");
      }
    });
  }
});

// Supprimez tous les ingrédients et les burgers
Promise.all([Ingredient.deleteMany({}), Burger.deleteMany({})])
  .then(() => {
    // Insérez les ingrédients
    const ingredient1 = new Ingredient({ nom: "Viande", quantite: 1 });
    const ingredient2 = new Ingredient({ nom: "Fromage", quantite: 1 });
    const ingredient3 = new Ingredient({ nom: "Salade", quantite: 1 });
    const ingredient4 = new Ingredient({ nom: "Tomate", quantite: 1 });
    const ingredient5 = new Ingredient({ nom: "Oignon rouge", quantite: 1 });

    return Promise.all([
      ingredient1.save(),
      ingredient2.save(),
      ingredient3.save(),
      ingredient4.save(),
      ingredient5.save(),
    ]);
  })
  .then((ingredients) => {
    console.log("Ingrédients mis à jour avec succès");

    // Utilisez les ingrédients retournés pour définir les burgers
    const [ingredient1, ingredient2, ingredient3, ingredient4, ingredient5] =
      ingredients;

    // Insérez des burgers
    const burger1 = new Burger({
      nom: "Burger Classique",
      categorie: "Halal",
      description:
        "Un burger classique avec du steak, du cheddar, de la salade et des tomates",
      prix: 9,
      ingredients: [ingredient1, ingredient2, ingredient3, ingredient4],
      image: "https://www.dinapoli-pizza29.fr/produit/496_240.png",
      quantite: 1,
      isCustom: false,
    });
    const burger2 = new Burger({
      nom: "Burger Végétarien",
      categorie: "Végétarien",
      description:
        "Un burger végétarien avec de la salade, des tomates et des oignons rouges",
      prix: 9.5,
      ingredients: [ingredient3, ingredient4, ingredient5],
      image: "https://www.dinapoli-pizza29.fr/produit/496_242.png",
      quantite: 1,
      isCustom: false,
    });
    const burger3 = new Burger({
      nom: "Burger au Bacon",
      categorie: "Populaire",
      description:
        "Un burger avec du steak, du cheddar, de la salade, des oignons rouges et du bacon",
      prix: 10,
      ingredients: [ingredient1, ingredient2, ingredient3, ingredient5],
      image: "https://www.dinapoli-pizza29.fr/produit/496_244.png",
      quantite: 1,
      isCustom: false,
    });
    const burger4 = new Burger({
      nom: "Burger au Fromage",
      categorie: "Halal",
      description: "Un burger avec du steak, du cheddar et des tomates",
      prix: 8,
      ingredients: [ingredient1, ingredient2, ingredient4],
      image: "https://www.dinapoli-pizza29.fr/produit/496_246.png",
      quantite: 1,
      isCustom: false,
    });
    const burger5 = new Burger({
      nom: "Burger au Poulet",
      categorie: "Halal",
      description: "Un burger avec du poulet, de la salade et des tomates",
      prix: 9.5,
      ingredients: [ingredient1, ingredient3, ingredient4],
      image: "https://www.dinapoli-pizza29.fr/produit/496_245.png",
      quantite: 1,
      isCustom: false,
    });
    const burger6 = new Burger({
      nom: "Burger Mexicain",
      categorie: "Épicé",
      description:
        "Un burger avec du steak, du cheddar, des tomates et des oignons rouges",
      prix: 10,
      ingredients: [ingredient1, ingredient2, ingredient4, ingredient5],
      image: "https://freepngimg.com/download/burger/22501-3-shack-burger.png",
      quantite: 1,
      isCustom: false,
    });
    const burger7 = new Burger({
      nom: "Burger de la Maison",
      categorie: "Populaire",
      description:
        "Un burger avec du steak, du cheddar, de la salade, des tomates et des oignons rouges",
      prix: 11,
      ingredients: [
        ingredient1,
        ingredient2,
        ingredient3,
        ingredient4,
        ingredient5,
      ],
      image: "https://www.dinapoli-pizza29.fr/produit/496_241.png",
      quantite: 1,
      isCustom: false,
    });
    const burger8 = new Burger({
      nom: "Burger au Chèvre",
      categorie: "Populaire",
      description:
        "Un burger avec du steak, du chèvre, des tomates et des oignons rouges",
      prix: 10.5,
      ingredients: [ingredient1, ingredient2, ingredient4, ingredient5],
      image:
        "https://fastburger-lens.fr/wp-content/uploads/2021/08/chevre-miel-fastburger-1.png",
      quantite: 1,
      isCustom: false,
    });
    const burger9 = new Burger({
      nom: "Burger de la Mer",
      categorie: "Populaire",
      description: "Un burger avec du poisson, de la salade et des tomates",
      prix: 11,
      ingredients: [ingredient1, ingredient3, ingredient4],
      image: "https://www.dinapoli-pizza29.fr/produit/496_243.png",
      quantite: 1,
      isCustom: false,
    });
    const burger10 = new Burger({
      nom: "Burger Vegan",
      categorie: "Végétarien",
      description:
        "Un burger vegan avec de la salade, des tomates et des oignons rouges",
      prix: 10.5,
      ingredients: [ingredient3, ingredient4, ingredient5],
      image: "https://www.dinapoli-pizza29.fr/produit/496_242.png",
      quantite: 1,
      isCustom: false,
    });

    return Promise.all([
      burger1.save(),
      burger2.save(),
      burger3.save(),
      burger4.save(),
      burger5.save(),
      burger6.save(),
      burger7.save(),
      burger8.save(),
      burger9.save(),
      burger10.save(),
    ]);
  })
  .then(() => {
    console.log("Burgers mis à jour avec succès");
  })
  .catch((err) => {
    console.error("Erreur lors de l'enregistrement des données", err);
  });

module.exports = app;
