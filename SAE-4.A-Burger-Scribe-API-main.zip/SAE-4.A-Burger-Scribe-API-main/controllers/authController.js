const bcrypt = require("bcrypt");
const User = require("../models/user");

exports.register = async (req, res) => {
  const { firstname, lastname, email, password } = req.body;

  try {
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({ message: "Cet e-mail est déjà utilisé" });
    }
    const hashedPassword = await bcrypt.hash(password, 10);

    const user = new User({
      firstname,
      lastname,
      email,
      password: hashedPassword,
    });
    await user.save();
    res.json({ message: "Utilisateur enregistré avec succès" });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      error:
        "Une erreur est survenue lors de l'enregistrement de l'utilisateur.",
    });
  }
};

exports.login = async (req, res) => {
  const { email, password } = req.body;

  try {
    const user = await User.findOne({ email });
    if (!user) {
      return res.status(400).json({ message: "Utilisateur non trouvé" });
    }

    const passwordValid = await bcrypt.compare(password, user.password);
    if (!passwordValid) {
      return res.status(400).json({ message: "Mot de passe incorrect" });
    }

    res.json({
      message: "Connexion réussie",
      id: user._id,
      lastname: user.lastname,
      firstname: user.firstname,
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      error: "Une erreur est survenue lors de la connexion de l'utilisateur.",
    });
  }
};

exports.updateUser = async (req, res) => {
  const { firstname, lastname, email } = req.body;

  try {
    const updatedUser = await User.findOneAndUpdate(
      { email },
      { firstname, lastname },
      { new: true }
    );

    if (!updatedUser) {
      return res.status(404).json({ message: "Utilisateur non trouvé" });
    }

    res.json({
      message: "Utilisateur mis à jour avec succès",
      user: updatedUser,
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      error: "Une erreur est survenue lors de la mise à jour de l'utilisateur.",
    });
  }
};

exports.changePassword = async (req, res) => {
  try {
    const newPassword = req.body.newPassword;
    const oldPassword = req.body.oldPassword;
    const email = req.body.email;

    const user = await User.findOne({ email });

    if (!user) {
      return res.status(404).json({ message: "Utilisateur non trouvé" });
    }

    const isMatch = await bcrypt.compare(oldPassword, user.password);

    if (!isMatch) {
      return res
        .status(400)
        .json({ message: "L'ancien mot de passe est incorrect" });
    }

    const hashedPassword = await bcrypt.hash(newPassword, 10);

    user.password = hashedPassword;
    await User.updateOne({ _id: user._id }, { password: hashedPassword });
    res.json({ message: "Mot de passe mis à jour avec succès" });
  } catch (error) {
    res.status(400).json({
      message: "Changement de mot de passe a échoué",
      error: error.message,
    });
  }
};
