const Panier = require("../models/panier");
const Burger = require("../models/burger");
const Ingredient = require("../models/ingredient");

// Fonction pour récupérer tous les paniers
exports.getPaniers = async (req, res) => {
  try {
    const paniers = await Panier.find()
      .populate("user")
      .populate({ path: "burgers", populate: { path: "ingredients" } });
    res.json(paniers);
  } catch (error) {
    console.error(error);
    res.status(500).json({
      error: "Une erreur est survenue lors de la récupération des paniers.",
    });
  }
};

// Fonction pour récupérer le panier actuel d'un utilisateur
exports.getPanier = async (req, res) => {
  const userId = req.params.id;
  try {
    let panier = await Panier.findOne({ user: userId, status: "pending" })
      .populate("user")
      .populate({ path: "burgers", populate: { path: "ingredients" } });

    // S'il n'y a pas de panier en cours, en créer un
    if (!panier) {
      const newPanier = new Panier({
        user: userId,
        burgers: [],
        status: "pending",
      });

      panier = await newPanier.save();
      panier = await Panier.findOne({ _id: panier._id })
        .populate("user")
        .populate({ path: "burgers", populate: { path: "ingredients" } });
    }

    res.json(panier);
  } catch (error) {
    console.error(error);
    res.status(500).json({
      error:
        "Une erreur est survenue lors de la récupération du panier actuel.",
    });
  }
};

// Fonction pour récupérer les paniers passé en comamande d'un utilisateur
exports.getPaniersUser = async (req, res) => {
  const userId = req.params.id;
  try {
    let paniers = await Panier.find({
      user: userId,
      status: { $in: ["completed", "in progress"] },
    })
      .populate("user")
      .populate({ path: "burgers", populate: { path: "ingredients" } });
    res.json(paniers);
  } catch (error) {
    console.error(error);
    res.status(500).json({
      error:
        "Une erreur est survenue lors de la récupération du panier actuel.",
    });
  }
};

// Fonction pour créer un nouveau panier
exports.createPanier = async (req, res) => {
  const { user, burgers } = req.body;

  try {
    const panier = new Panier({
      user,
      burgers,
    });
    await panier.save();
    res.json({ message: "Panier créé avec succès" });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      error: "Une erreur est survenue lors de la création du panier.",
    });
  }
};

// Fonction pour mettre à jour un panier existant
exports.updatePanier = async (req, res) => {
  const { id } = req.params;
  const { user, burgers, status } = req.body;

  try {
    const panier = await Panier.findByIdAndUpdate(
      id,
      {
        user,
        burgers,
        status,
      },
      { new: true }
    );
    res.json({ message: "Panier mis à jour avec succès", panier });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      error: "Une erreur est survenue lors de la mise à jour du panier.",
    });
  }
};

// Fonction pour supprimer un panier existant
exports.deletePanier = async (req, res) => {
  const { id } = req.params;

  try {
    await Panier.findByIdAndDelete(id);
    res.json({ message: "Panier supprimé avec succès" });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      error: "Une erreur est survenue lors de la suppression du panier.",
    });
  }
};

// Fonction pour ajouter un burger à un panier
exports.addBurgerToPanier = async (req, res) => {
  const userId = req.params.id;
  const burger = req.body;

  try {
    let panier = await Panier.findOne({ user: userId, status: "pending" })
      .populate("user")
      .populate({ path: "burgers", populate: { path: "ingredients" } });

    const existingBurger = panier?.burgers.find(
      (b) =>
        b.isCustom === true &&
        b.ingredients.length === burger.ingredients.length &&
        b.ingredients.every((ing) =>
          burger.ingredients.some(
            (origIng) =>
              origIng.nom === ing.nom && origIng.quantite === ing.quantite
          )
        )
    );

    if (existingBurger) {
      existingBurger.quantite += 1;
      await existingBurger.save();
    } else {
      const newIngredients = await Promise.all(
        burger.ingredients.map(async (ingredient) => {
          const newIngredient = new Ingredient({
            nom: ingredient.nom,
            quantite: ingredient.quantite,
          });
          await newIngredient.save();
          return newIngredient._id;
        })
      );

      const newBurger = new Burger({
        ...burger,
        ingredients: newIngredients,
        isCustom: true,
      });
      await newBurger.save();

      if (!panier) {
        panier = new Panier({
          user: userId,
          burgers: [newBurger],
          status: "pending",
          prixtotal: 0,
        });
        await panier.save();
      } else {
        panier.burgers.push(newBurger);
        await panier.save();
      }
    }

    panier = await Panier.findOne({ _id: panier._id })
      .populate("user")
      .populate({ path: "burgers", populate: { path: "ingredients" } });

    res.json(panier);
  } catch (error) {
    console.error(error);
    res.status(500).json({
      error: "Une erreur est survenue lors de l'ajout du burger au panier.",
    });
  }
};

exports.updateBurgerQuantity = async (req, res) => {
  const burgerId = req.params.burgerId;
  const quantity = req.query.quantity;

  try {
    const burger = await Burger.findById(burgerId);
    if (!burger) {
      return res.status(404).json({ error: "Burger introuvable" });
    }

    burger.quantite = parseInt(quantity, 10);
    await burger.save();

    res
      .status(200)
      .json({ message: "Quantité du burger mise à jour avec succès" });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      error:
        "Une erreur s'est produite lors de la mise à jour de la quantité du burger",
    });
  }
};

exports.removeBurgerFromPanier = async (req, res) => {
  const panierId = req.params.panierId;
  const burgerId = req.params.burgerId;

  try {
    const panier = await Panier.findById(panierId);
    if (!panier) {
      return res.status(404).json({ error: "Panier introuvable" });
    }

    panier.burgers.pull(burgerId);
    await panier.save();

    res.status(200).json({ message: "Burger retiré du panier avec succès" });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      error:
        "Une erreur s'est produite lors de la suppression du burger du panier",
    });
  }
};

// Fonction pour mettre à jour le statut d'un panier
exports.updatePanierStatus = async (req, res) => {
  const { id } = req.params;
  const status = req.body.status;
  const prixtotalString = req.body.prixtotal;
  const prixtotal = parseFloat(prixtotalString);

  try {
    const panier = await Panier.findById(id);
    if (!panier) {
      return res.status(404).json({ error: "Panier introuvable" });
    }

    panier.status = status;
    panier.prixtotal = prixtotal;
    await panier.save();

    res
      .status(200)
      .json({ message: "Statut du panier mis à jour avec succès" });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      error:
        "Une erreur est survenue lors de la mise à jour du statut du panier.",
    });
  }
};
