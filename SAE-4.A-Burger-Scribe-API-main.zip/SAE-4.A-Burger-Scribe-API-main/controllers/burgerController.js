const Burger = require("../models/burger");

exports.getBurgers = async (req, res) => {
  try {
    const burgers = await Burger.find().populate("ingredients");
    res.json(burgers);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Une erreur est survenue" });
  }
};

exports.createBurger = async (req, res) => {
  const { nom, ingredients, image } = req.body;

  try {
    const burger = new Burger({ nom, ingredients, image });
    await burger.save();
    res.json({ message: "Burger créé avec succès" });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Une erreur est survenue" });
  }
};

exports.updateBurger = async (req, res) => {
  const { id } = req.params;
  const { nom, ingredients, image } = req.body;

  try {
    const burger = await Burger.findByIdAndUpdate(
      id,
      { nom, ingredients, image },
      { new: true }
    );
    res.json({ message: "Burger mis à jour avec succès", burger });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Une erreur est survenue" });
  }
};

exports.deleteBurger = async (req, res) => {
  const { id } = req.params;

  try {
    await Burger.findByIdAndDelete(id);
    res.json({ message: "Burger supprimé avec succès" });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Une erreur est survenue" });
  }
};
