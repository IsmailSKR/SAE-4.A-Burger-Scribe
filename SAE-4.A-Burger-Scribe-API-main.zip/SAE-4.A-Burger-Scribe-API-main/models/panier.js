const mongoose = require("mongoose");

const panierSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
    required: true,
  },
  burgers: [
    {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Burger",
    },
  ],
  status: {
    type: String,
    enum: ["pending", "in progress", "completed"],
    default: "pending",
  },
  prixtotal: {
    type: Number,
    default: 0,
  },
});

module.exports = mongoose.model("Panier", panierSchema);
