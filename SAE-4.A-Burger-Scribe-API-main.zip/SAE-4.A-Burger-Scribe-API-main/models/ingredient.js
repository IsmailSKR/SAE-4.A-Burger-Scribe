const mongoose = require("mongoose");

const ingredientSchema = new mongoose.Schema({
  nom: {
    type: String,
    required: true,
  },
  quantite: {
    type: Number,
    default: 1,
  },
});

module.exports = mongoose.model("Ingredient", ingredientSchema);
