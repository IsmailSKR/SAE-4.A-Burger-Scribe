const mongoose = require("mongoose");

const burgerSchema = new mongoose.Schema({
  nom: {
    type: String,
    required: true,
  },
  categorie: {
    type: String,
    required: true,
  },
  description: {
    type: String,
    required: true,
  },
  prix: {
    type: Number,
    required: true,
  },
  ingredients: [
    {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Ingredient",
    },
  ],
  image: {
    type: String,
    required: true,
  },
  quantite: {
    type: Number,
    default: 1,
  },
  isCustom: {
    type: Boolean,
    default: false,
  },
});

module.exports = mongoose.model("Burger", burgerSchema);
